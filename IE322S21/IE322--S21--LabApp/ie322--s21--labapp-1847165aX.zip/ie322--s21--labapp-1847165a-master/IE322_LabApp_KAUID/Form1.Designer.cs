﻿
namespace IE322_LabApp_KAUID
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.TxtPW = new System.Windows.Forms.TextBox();
            this.TxtUser = new System.Windows.Forms.TextBox();
            this.pass = new System.Windows.Forms.Label();
            this.User = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnCombo = new System.Windows.Forms.Button();
            this.btnCheckBox = new System.Windows.Forms.Button();
            this.btnRadio = new System.Windows.Forms.Button();
            this.groupGraphical = new System.Windows.Forms.GroupBox();
            this.btnPictureBox2 = new System.Windows.Forms.Button();
            this.btnGroupieApp = new System.Windows.Forms.Button();
            this.btnSelfieApp = new System.Windows.Forms.Button();
            this.btnPictureBox = new System.Windows.Forms.Button();
            this.groupMoreControls = new System.Windows.Forms.GroupBox();
            this.btnRandom = new System.Windows.Forms.Button();
            this.btnRandomCombo = new System.Windows.Forms.Button();
            this.btnTimer = new System.Windows.Forms.Button();
            this.btnProgress = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnDraw = new System.Windows.Forms.Button();
            this.btnSystem = new System.Windows.Forms.Button();
            this.btnTalk = new System.Windows.Forms.Button();
            this.groupMicro = new System.Windows.Forms.GroupBox();
            this.btnArduino = new System.Windows.Forms.Button();
            this.groupExam = new System.Windows.Forms.GroupBox();
            this.btnMongo = new System.Windows.Forms.Button();
            this.btnJohari = new System.Windows.Forms.Button();
            this.btnABC = new System.Windows.Forms.Button();
            this.btnRobotic = new System.Windows.Forms.Button();
            this.btnManufacturing = new System.Windows.Forms.Button();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.groupOperators = new System.Windows.Forms.GroupBox();
            this.btnStrings = new System.Windows.Forms.Button();
            this.btnOperators = new System.Windows.Forms.Button();
            this.btnDataType = new System.Windows.Forms.Button();
            this.groupDataStructures = new System.Windows.Forms.GroupBox();
            this.btnCollections = new System.Windows.Forms.Button();
            this.btnArrays = new System.Windows.Forms.Button();
            this.btnMethods = new System.Windows.Forms.Button();
            this.groupObjectOriented = new System.Windows.Forms.GroupBox();
            this.btnEvents = new System.Windows.Forms.Button();
            this.btnClasses = new System.Windows.Forms.Button();
            this.groupDecisionItration = new System.Windows.Forms.GroupBox();
            this.Itreration = new System.Windows.Forms.Button();
            this.btnDecision = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupGraphical.SuspendLayout();
            this.groupMoreControls.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupMicro.SuspendLayout();
            this.groupExam.SuspendLayout();
            this.groupOperators.SuspendLayout();
            this.groupDataStructures.SuspendLayout();
            this.groupObjectOriented.SuspendLayout();
            this.groupDecisionItration.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.TxtPW);
            this.groupBox1.Controls.Add(this.TxtUser);
            this.groupBox1.Controls.Add(this.pass);
            this.groupBox1.Controls.Add(this.User);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Location = new System.Drawing.Point(47, 50);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 288);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "sign in to IE322";
            // 
            // TxtPW
            // 
            this.TxtPW.Location = new System.Drawing.Point(20, 157);
            this.TxtPW.Name = "TxtPW";
            this.TxtPW.Size = new System.Drawing.Size(100, 26);
            this.TxtPW.TabIndex = 4;
            // 
            // TxtUser
            // 
            this.TxtUser.Location = new System.Drawing.Point(20, 86);
            this.TxtUser.Name = "TxtUser";
            this.TxtUser.Size = new System.Drawing.Size(100, 26);
            this.TxtUser.TabIndex = 3;
            // 
            // pass
            // 
            this.pass.AutoSize = true;
            this.pass.Location = new System.Drawing.Point(23, 134);
            this.pass.Name = "pass";
            this.pass.Size = new System.Drawing.Size(77, 20);
            this.pass.TabIndex = 2;
            this.pass.Text = "password";
            // 
            // User
            // 
            this.User.AutoSize = true;
            this.User.Location = new System.Drawing.Point(16, 63);
            this.User.Name = "User";
            this.User.Size = new System.Drawing.Size(84, 20);
            this.User.TabIndex = 1;
            this.User.Text = "user name";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(20, 220);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 44);
            this.button1.TabIndex = 0;
            this.button1.Text = "sign in";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnCombo);
            this.groupBox2.Controls.Add(this.btnCheckBox);
            this.groupBox2.Controls.Add(this.btnRadio);
            this.groupBox2.Location = new System.Drawing.Point(304, 50);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(256, 142);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Basic controls";
            // 
            // btnCombo
            // 
            this.btnCombo.Location = new System.Drawing.Point(76, 99);
            this.btnCombo.Name = "btnCombo";
            this.btnCombo.Size = new System.Drawing.Size(98, 29);
            this.btnCombo.TabIndex = 2;
            this.btnCombo.Text = "Combo";
            this.btnCombo.UseVisualStyleBackColor = true;
            // 
            // btnCheckBox
            // 
            this.btnCheckBox.Location = new System.Drawing.Point(123, 38);
            this.btnCheckBox.Name = "btnCheckBox";
            this.btnCheckBox.Size = new System.Drawing.Size(101, 31);
            this.btnCheckBox.TabIndex = 1;
            this.btnCheckBox.Text = "CheckBox";
            this.btnCheckBox.UseVisualStyleBackColor = true;
            // 
            // btnRadio
            // 
            this.btnRadio.Location = new System.Drawing.Point(16, 38);
            this.btnRadio.Name = "btnRadio";
            this.btnRadio.Size = new System.Drawing.Size(81, 31);
            this.btnRadio.TabIndex = 0;
            this.btnRadio.Text = "Radio";
            this.btnRadio.UseVisualStyleBackColor = true;
            this.btnRadio.Click += new System.EventHandler(this.button2_Click);
            // 
            // groupGraphical
            // 
            this.groupGraphical.Controls.Add(this.btnPictureBox2);
            this.groupGraphical.Controls.Add(this.btnGroupieApp);
            this.groupGraphical.Controls.Add(this.btnSelfieApp);
            this.groupGraphical.Controls.Add(this.btnPictureBox);
            this.groupGraphical.Location = new System.Drawing.Point(304, 233);
            this.groupGraphical.Name = "groupGraphical";
            this.groupGraphical.Size = new System.Drawing.Size(273, 147);
            this.groupGraphical.TabIndex = 2;
            this.groupGraphical.TabStop = false;
            this.groupGraphical.Text = "Graphical";
            this.groupGraphical.Enter += new System.EventHandler(this.groupGraphical_Enter);
            // 
            // btnPictureBox2
            // 
            this.btnPictureBox2.Location = new System.Drawing.Point(16, 85);
            this.btnPictureBox2.Name = "btnPictureBox2";
            this.btnPictureBox2.Size = new System.Drawing.Size(118, 46);
            this.btnPictureBox2.TabIndex = 3;
            this.btnPictureBox2.Text = "PictureBox2";
            this.btnPictureBox2.UseVisualStyleBackColor = true;
            // 
            // btnGroupieApp
            // 
            this.btnGroupieApp.Location = new System.Drawing.Point(149, 85);
            this.btnGroupieApp.Name = "btnGroupieApp";
            this.btnGroupieApp.Size = new System.Drawing.Size(118, 46);
            this.btnGroupieApp.TabIndex = 2;
            this.btnGroupieApp.Text = "Groupie App";
            this.btnGroupieApp.UseVisualStyleBackColor = true;
            // 
            // btnSelfieApp
            // 
            this.btnSelfieApp.Location = new System.Drawing.Point(149, 31);
            this.btnSelfieApp.Name = "btnSelfieApp";
            this.btnSelfieApp.Size = new System.Drawing.Size(118, 39);
            this.btnSelfieApp.TabIndex = 1;
            this.btnSelfieApp.Text = "Selfie App";
            this.btnSelfieApp.UseVisualStyleBackColor = true;
            // 
            // btnPictureBox
            // 
            this.btnPictureBox.Location = new System.Drawing.Point(16, 31);
            this.btnPictureBox.Name = "btnPictureBox";
            this.btnPictureBox.Size = new System.Drawing.Size(118, 39);
            this.btnPictureBox.TabIndex = 0;
            this.btnPictureBox.Text = "PictureBox";
            this.btnPictureBox.UseVisualStyleBackColor = true;
            // 
            // groupMoreControls
            // 
            this.groupMoreControls.Controls.Add(this.btnRandom);
            this.groupMoreControls.Controls.Add(this.btnRandomCombo);
            this.groupMoreControls.Controls.Add(this.btnTimer);
            this.groupMoreControls.Controls.Add(this.btnProgress);
            this.groupMoreControls.Location = new System.Drawing.Point(304, 404);
            this.groupMoreControls.Name = "groupMoreControls";
            this.groupMoreControls.Size = new System.Drawing.Size(294, 174);
            this.groupMoreControls.TabIndex = 3;
            this.groupMoreControls.TabStop = false;
            this.groupMoreControls.Text = "More Controls";
            // 
            // btnRandom
            // 
            this.btnRandom.Location = new System.Drawing.Point(6, 101);
            this.btnRandom.Name = "btnRandom";
            this.btnRandom.Size = new System.Drawing.Size(131, 38);
            this.btnRandom.TabIndex = 3;
            this.btnRandom.Text = "Random";
            this.btnRandom.UseVisualStyleBackColor = true;
            // 
            // btnRandomCombo
            // 
            this.btnRandomCombo.Location = new System.Drawing.Point(149, 101);
            this.btnRandomCombo.Name = "btnRandomCombo";
            this.btnRandomCombo.Size = new System.Drawing.Size(133, 38);
            this.btnRandomCombo.TabIndex = 2;
            this.btnRandomCombo.Text = "Random Combo";
            this.btnRandomCombo.UseVisualStyleBackColor = true;
            this.btnRandomCombo.Click += new System.EventHandler(this.button4_Click);
            // 
            // btnTimer
            // 
            this.btnTimer.Location = new System.Drawing.Point(149, 45);
            this.btnTimer.Name = "btnTimer";
            this.btnTimer.Size = new System.Drawing.Size(133, 39);
            this.btnTimer.TabIndex = 1;
            this.btnTimer.Text = "Timer";
            this.btnTimer.UseVisualStyleBackColor = true;
            this.btnTimer.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnProgress
            // 
            this.btnProgress.Location = new System.Drawing.Point(6, 45);
            this.btnProgress.Name = "btnProgress";
            this.btnProgress.Size = new System.Drawing.Size(131, 39);
            this.btnProgress.TabIndex = 0;
            this.btnProgress.Text = "Progress";
            this.btnProgress.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnDraw);
            this.groupBox3.Controls.Add(this.btnSystem);
            this.groupBox3.Controls.Add(this.btnTalk);
            this.groupBox3.Location = new System.Drawing.Point(304, 587);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(294, 108);
            this.groupBox3.TabIndex = 4;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "groupBox3";
            // 
            // btnDraw
            // 
            this.btnDraw.Location = new System.Drawing.Point(16, 25);
            this.btnDraw.Name = "btnDraw";
            this.btnDraw.Size = new System.Drawing.Size(81, 33);
            this.btnDraw.TabIndex = 2;
            this.btnDraw.Text = "Draw";
            this.btnDraw.UseVisualStyleBackColor = true;
            // 
            // btnSystem
            // 
            this.btnSystem.Location = new System.Drawing.Point(99, 64);
            this.btnSystem.Name = "btnSystem";
            this.btnSystem.Size = new System.Drawing.Size(86, 38);
            this.btnSystem.TabIndex = 1;
            this.btnSystem.Text = "System";
            this.btnSystem.UseVisualStyleBackColor = true;
            // 
            // btnTalk
            // 
            this.btnTalk.Location = new System.Drawing.Point(149, 25);
            this.btnTalk.Name = "btnTalk";
            this.btnTalk.Size = new System.Drawing.Size(107, 33);
            this.btnTalk.TabIndex = 0;
            this.btnTalk.Text = "Talk";
            this.btnTalk.UseVisualStyleBackColor = true;
            // 
            // groupMicro
            // 
            this.groupMicro.Controls.Add(this.btnArduino);
            this.groupMicro.Location = new System.Drawing.Point(988, 50);
            this.groupMicro.Name = "groupMicro";
            this.groupMicro.Size = new System.Drawing.Size(211, 96);
            this.groupMicro.TabIndex = 5;
            this.groupMicro.TabStop = false;
            this.groupMicro.Text = "Micro Controller";
            // 
            // btnArduino
            // 
            this.btnArduino.Location = new System.Drawing.Point(72, 37);
            this.btnArduino.Name = "btnArduino";
            this.btnArduino.Size = new System.Drawing.Size(94, 46);
            this.btnArduino.TabIndex = 1;
            this.btnArduino.Text = "Arduino";
            this.btnArduino.UseVisualStyleBackColor = true;
            // 
            // groupExam
            // 
            this.groupExam.Controls.Add(this.btnMongo);
            this.groupExam.Controls.Add(this.btnJohari);
            this.groupExam.Controls.Add(this.btnABC);
            this.groupExam.Controls.Add(this.btnRobotic);
            this.groupExam.Controls.Add(this.btnManufacturing);
            this.groupExam.Location = new System.Drawing.Point(629, 50);
            this.groupExam.Name = "groupExam";
            this.groupExam.Size = new System.Drawing.Size(308, 474);
            this.groupExam.TabIndex = 4;
            this.groupExam.TabStop = false;
            this.groupExam.Text = "Exam Apps";
            // 
            // btnMongo
            // 
            this.btnMongo.Location = new System.Drawing.Point(35, 376);
            this.btnMongo.Name = "btnMongo";
            this.btnMongo.Size = new System.Drawing.Size(235, 49);
            this.btnMongo.TabIndex = 5;
            this.btnMongo.Text = "MongoDB";
            this.btnMongo.UseVisualStyleBackColor = true;
            // 
            // btnJohari
            // 
            this.btnJohari.Location = new System.Drawing.Point(35, 305);
            this.btnJohari.Name = "btnJohari";
            this.btnJohari.Size = new System.Drawing.Size(235, 49);
            this.btnJohari.TabIndex = 4;
            this.btnJohari.Text = "Johari";
            this.btnJohari.UseVisualStyleBackColor = true;
            // 
            // btnABC
            // 
            this.btnABC.Location = new System.Drawing.Point(35, 230);
            this.btnABC.Name = "btnABC";
            this.btnABC.Size = new System.Drawing.Size(235, 58);
            this.btnABC.TabIndex = 3;
            this.btnABC.Text = "ABC Analysis";
            this.btnABC.UseVisualStyleBackColor = true;
            // 
            // btnRobotic
            // 
            this.btnRobotic.Location = new System.Drawing.Point(35, 138);
            this.btnRobotic.Name = "btnRobotic";
            this.btnRobotic.Size = new System.Drawing.Size(235, 65);
            this.btnRobotic.TabIndex = 2;
            this.btnRobotic.Text = "Robotic Cell.";
            this.btnRobotic.UseVisualStyleBackColor = true;
            // 
            // btnManufacturing
            // 
            this.btnManufacturing.Location = new System.Drawing.Point(35, 46);
            this.btnManufacturing.Name = "btnManufacturing";
            this.btnManufacturing.Size = new System.Drawing.Size(235, 66);
            this.btnManufacturing.TabIndex = 1;
            this.btnManufacturing.Text = "Manufacturing Cell";
            this.btnManufacturing.UseVisualStyleBackColor = true;
            // 
            // groupOperators
            // 
            this.groupOperators.Controls.Add(this.btnStrings);
            this.groupOperators.Controls.Add(this.btnOperators);
            this.groupOperators.Controls.Add(this.btnDataType);
            this.groupOperators.Location = new System.Drawing.Point(629, 530);
            this.groupOperators.Name = "groupOperators";
            this.groupOperators.Size = new System.Drawing.Size(321, 172);
            this.groupOperators.TabIndex = 6;
            this.groupOperators.TabStop = false;
            this.groupOperators.Text = "Operators";
            // 
            // btnStrings
            // 
            this.btnStrings.Location = new System.Drawing.Point(35, 135);
            this.btnStrings.Name = "btnStrings";
            this.btnStrings.Size = new System.Drawing.Size(235, 30);
            this.btnStrings.TabIndex = 2;
            this.btnStrings.Text = "Strings";
            this.btnStrings.UseVisualStyleBackColor = true;
            // 
            // btnOperators
            // 
            this.btnOperators.Location = new System.Drawing.Point(35, 85);
            this.btnOperators.Name = "btnOperators";
            this.btnOperators.Size = new System.Drawing.Size(235, 30);
            this.btnOperators.TabIndex = 1;
            this.btnOperators.Text = "Operators";
            this.btnOperators.UseVisualStyleBackColor = true;
            // 
            // btnDataType
            // 
            this.btnDataType.Location = new System.Drawing.Point(35, 44);
            this.btnDataType.Name = "btnDataType";
            this.btnDataType.Size = new System.Drawing.Size(235, 30);
            this.btnDataType.TabIndex = 0;
            this.btnDataType.Text = "Data Types";
            this.btnDataType.UseVisualStyleBackColor = true;
            // 
            // groupDataStructures
            // 
            this.groupDataStructures.Controls.Add(this.btnCollections);
            this.groupDataStructures.Controls.Add(this.btnArrays);
            this.groupDataStructures.Location = new System.Drawing.Point(969, 184);
            this.groupDataStructures.Name = "groupDataStructures";
            this.groupDataStructures.Size = new System.Drawing.Size(230, 180);
            this.groupDataStructures.TabIndex = 7;
            this.groupDataStructures.TabStop = false;
            this.groupDataStructures.Text = "Data Structures";
            // 
            // btnCollections
            // 
            this.btnCollections.Location = new System.Drawing.Point(19, 113);
            this.btnCollections.Name = "btnCollections";
            this.btnCollections.Size = new System.Drawing.Size(191, 41);
            this.btnCollections.TabIndex = 1;
            this.btnCollections.Text = "Collections";
            this.btnCollections.UseVisualStyleBackColor = true;
            // 
            // btnArrays
            // 
            this.btnArrays.Location = new System.Drawing.Point(19, 49);
            this.btnArrays.Name = "btnArrays";
            this.btnArrays.Size = new System.Drawing.Size(191, 41);
            this.btnArrays.TabIndex = 0;
            this.btnArrays.Text = "Arrays";
            this.btnArrays.UseVisualStyleBackColor = true;
            this.btnArrays.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // btnMethods
            // 
            this.btnMethods.Location = new System.Drawing.Point(19, 34);
            this.btnMethods.Name = "btnMethods";
            this.btnMethods.Size = new System.Drawing.Size(191, 37);
            this.btnMethods.TabIndex = 2;
            this.btnMethods.Text = "Methods";
            this.btnMethods.UseVisualStyleBackColor = true;
            // 
            // groupObjectOriented
            // 
            this.groupObjectOriented.Controls.Add(this.btnEvents);
            this.groupObjectOriented.Controls.Add(this.btnClasses);
            this.groupObjectOriented.Controls.Add(this.btnMethods);
            this.groupObjectOriented.Location = new System.Drawing.Point(969, 370);
            this.groupObjectOriented.Name = "groupObjectOriented";
            this.groupObjectOriented.Size = new System.Drawing.Size(230, 173);
            this.groupObjectOriented.TabIndex = 8;
            this.groupObjectOriented.TabStop = false;
            this.groupObjectOriented.Text = "Object Oriented";
            // 
            // btnEvents
            // 
            this.btnEvents.Location = new System.Drawing.Point(19, 124);
            this.btnEvents.Name = "btnEvents";
            this.btnEvents.Size = new System.Drawing.Size(191, 37);
            this.btnEvents.TabIndex = 4;
            this.btnEvents.Text = "Events";
            this.btnEvents.UseVisualStyleBackColor = true;
            // 
            // btnClasses
            // 
            this.btnClasses.Location = new System.Drawing.Point(19, 81);
            this.btnClasses.Name = "btnClasses";
            this.btnClasses.Size = new System.Drawing.Size(191, 37);
            this.btnClasses.TabIndex = 3;
            this.btnClasses.Text = "Classes";
            this.btnClasses.UseVisualStyleBackColor = true;
            // 
            // groupDecisionItration
            // 
            this.groupDecisionItration.Controls.Add(this.Itreration);
            this.groupDecisionItration.Controls.Add(this.btnDecision);
            this.groupDecisionItration.Location = new System.Drawing.Point(969, 561);
            this.groupDecisionItration.Name = "groupDecisionItration";
            this.groupDecisionItration.Size = new System.Drawing.Size(230, 134);
            this.groupDecisionItration.TabIndex = 9;
            this.groupDecisionItration.TabStop = false;
            this.groupDecisionItration.Text = "Decision Iteration";
            // 
            // Itreration
            // 
            this.Itreration.Location = new System.Drawing.Point(19, 79);
            this.Itreration.Name = "Itreration";
            this.Itreration.Size = new System.Drawing.Size(191, 37);
            this.Itreration.TabIndex = 4;
            this.Itreration.Text = "Itreration";
            this.Itreration.UseVisualStyleBackColor = true;
            // 
            // btnDecision
            // 
            this.btnDecision.Location = new System.Drawing.Point(19, 26);
            this.btnDecision.Name = "btnDecision";
            this.btnDecision.Size = new System.Drawing.Size(191, 37);
            this.btnDecision.TabIndex = 3;
            this.btnDecision.Text = "Decision";
            this.btnDecision.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 50);
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::IE322_LabApp_KAUID.Properties.Resources.IE_LOGO4_19112019;
            this.pictureBox2.Location = new System.Drawing.Point(12, 355);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(240, 225);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 11;
            this.pictureBox2.TabStop = false;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnExit.Location = new System.Drawing.Point(12, 586);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(235, 103);
            this.btnExit.TabIndex = 12;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            // 
            // frmMain
            // 
            this.AccessibleDescription = "By Dr. Atif Shahzad";
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1228, 707);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupDecisionItration);
            this.Controls.Add(this.groupObjectOriented);
            this.Controls.Add(this.groupDataStructures);
            this.Controls.Add(this.groupOperators);
            this.Controls.Add(this.groupExam);
            this.Controls.Add(this.groupMicro);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupMoreControls);
            this.Controls.Add(this.groupGraphical);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "frmMain";
            this.Text = "Main_IE322_KAUID";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupGraphical.ResumeLayout(false);
            this.groupMoreControls.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupMicro.ResumeLayout(false);
            this.groupExam.ResumeLayout(false);
            this.groupOperators.ResumeLayout(false);
            this.groupDataStructures.ResumeLayout(false);
            this.groupObjectOriented.ResumeLayout(false);
            this.groupDecisionItration.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox TxtPW;
        private System.Windows.Forms.TextBox TxtUser;
        private System.Windows.Forms.Label pass;
        private System.Windows.Forms.Label User;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnRadio;
        private System.Windows.Forms.Button btnCombo;
        private System.Windows.Forms.Button btnCheckBox;
        private System.Windows.Forms.GroupBox groupGraphical;
        private System.Windows.Forms.Button btnPictureBox2;
        private System.Windows.Forms.Button btnGroupieApp;
        private System.Windows.Forms.Button btnSelfieApp;
        private System.Windows.Forms.Button btnPictureBox;
        private System.Windows.Forms.GroupBox groupMoreControls;
        private System.Windows.Forms.Button btnRandom;
        private System.Windows.Forms.Button btnRandomCombo;
        private System.Windows.Forms.Button btnTimer;
        private System.Windows.Forms.Button btnProgress;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnDraw;
        private System.Windows.Forms.Button btnSystem;
        private System.Windows.Forms.Button btnTalk;
        private System.Windows.Forms.GroupBox groupMicro;
        private System.Windows.Forms.Button btnArduino;
        private System.Windows.Forms.GroupBox groupExam;
        private System.Windows.Forms.Button btnRobotic;
        private System.Windows.Forms.Button btnManufacturing;
        private System.Windows.Forms.Button btnMongo;
        private System.Windows.Forms.Button btnJohari;
        private System.Windows.Forms.Button btnABC;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.GroupBox groupOperators;
        private System.Windows.Forms.Button btnStrings;
        private System.Windows.Forms.Button btnOperators;
        private System.Windows.Forms.Button btnDataType;
        private System.Windows.Forms.GroupBox groupDataStructures;
        private System.Windows.Forms.Button btnMethods;
        private System.Windows.Forms.Button btnCollections;
        private System.Windows.Forms.Button btnArrays;
        private System.Windows.Forms.GroupBox groupObjectOriented;
        private System.Windows.Forms.Button btnEvents;
        private System.Windows.Forms.Button btnClasses;
        private System.Windows.Forms.GroupBox groupDecisionItration;
        private System.Windows.Forms.Button Itreration;
        private System.Windows.Forms.Button btnDecision;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button btnExit;
    }
}


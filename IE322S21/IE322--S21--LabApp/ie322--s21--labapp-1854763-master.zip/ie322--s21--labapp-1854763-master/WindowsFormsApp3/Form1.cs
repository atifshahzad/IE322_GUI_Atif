﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp3;

namespace IE322_LabApp_KAUID
{
    public partial class frmMain : Form
    {
        string username = "";      //"Atif"; //username
        string myPassword = "";    //"1234"; //password

        bool loggedIn = false;

        int ThisAttempt = 1;
        int MaxAttempts = 3;
        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {


            if (!loggedIn)
            {
                while (ThisAttempt <= MaxAttempts)
                {
                    if (txtuser.Text != username)
                    {
                        // username is incorrect
                        MessageBox.Show("Invalid username, " + (MaxAttempts - ThisAttempt) + " attempts remaining");
                        ThisAttempt++; //
                        return;
                    }
                    else
                    {   // username is correct
                        // so check password			
                        if (txtpassword.Text != myPassword)
                        {
                            // Incorrect password                            
                            MessageBox.Show("Incorrect password," + (MaxAttempts - ThisAttempt) + " attempts remaining");
                            ThisAttempt++;
                            return;
                        }
                        else
                        {
                            //Both are correct
                            ThisAttempt = 1; // reset the number of attempts
                            loggedIn = true;
                            MessageBox.Show("Hi " + username + ", your login successful", "Welcome!!");

                            btnLogin.Text = "Logout";

                            // this.Width = 1600;
                            break; // come out of while loop
                        }//endif

                    }//endif
                }//end while
            }
            else
            {
                btnLogin.Text = "Login";

                loggedIn = false;

                txtuser.Clear();
                txtpassword.Clear();

            }
            //end login Button
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void TxtPW_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxtUser_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnRadio_Click(object sender, EventArgs e)
        {
            frmRadio frm = new frmRadio();

            frm.ShowDialog();
        }
    }
}

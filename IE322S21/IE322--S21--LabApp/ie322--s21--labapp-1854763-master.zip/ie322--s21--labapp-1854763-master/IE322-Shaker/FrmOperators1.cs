﻿using System;

namespace IE322_Shaker
{
    internal class FrmOperators
    {
        internal void ShowDialog()
        {
            throw new NotImplementedException();
        }
    }
}